package com.javier.simplemvc.interfaces;

import com.javier.simplemvc.patterns.notify.NotifyMessage;

/**
 * author:Javier
 * time:2016/5/28.
 * mail:38244704@qq.com
 */
public interface IObserverFunction  {
    void ObserverFunction(NotifyMessage message);
}
