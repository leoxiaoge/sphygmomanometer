package com.javier.simplemvc.interfaces;

/**
 * author:Javier
 * time:2016/4/30.
 * mail:38244704@qq.com
 */
public interface IEncrypt {
    String encrypt(String param);
    String decrypt(String param);
}
