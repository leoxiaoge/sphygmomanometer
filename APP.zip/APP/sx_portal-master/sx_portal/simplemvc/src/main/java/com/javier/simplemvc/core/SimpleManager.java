package com.javier.simplemvc.core;

import com.javier.simplemvc.interfaces.IManager;

/**
 * author:Javier
 * time:2016/5/28.
 * mail:38244704@qq.com
 */
public abstract class SimpleManager implements IManager {
}
