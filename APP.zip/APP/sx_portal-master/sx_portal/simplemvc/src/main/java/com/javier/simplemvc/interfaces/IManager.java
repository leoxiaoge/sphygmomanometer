package com.javier.simplemvc.interfaces;

/**
 * author:Javier
 * time:2016/5/29.
 * mail:38244704@qq.com
 */
public interface IManager {
    void destroy();
}
