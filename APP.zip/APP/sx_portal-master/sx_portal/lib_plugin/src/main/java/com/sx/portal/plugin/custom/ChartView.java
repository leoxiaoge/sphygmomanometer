package com.sx.portal.plugin.custom;

/**
 * author:Javier
 * time:2016/6/11.
 * mail:38244704@qq.com
 */
public class ChartView {
}
